/**
 * This is the exceptions package. It contains all exceptions created by us.
 * All classes extend Exception class or a subclass
 *
 * Alunos:
 * @author André Oliveira 45648
 * @author Tânia Maldonado 44745
 *
 */
package fcul.pco.teletasca.exceptions;